import os
#os.system('amixer set "WONDERBOOM - A2DP"  unmute')
#os.system('amixer set "WONDERBOOM - A2DP"  100%')
os.system('omxplayer /home/pi/Desktop/beep.mp3')

#https://www.amazon.com/TROND-Bluetooth-Transmitter-Headphones-Simultaneously/dp/B01B4W40VC/ref=sr_1_5?keywords=bluetooth+3.5mm+transmitter&qid=1582069522&sr=8-5