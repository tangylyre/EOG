from inputimeout import inputimeout, TimeoutOccurred

while True:
    try:
        print("shit")
    except KeyboardInterrupt:
        break
print("loop is broken!")
